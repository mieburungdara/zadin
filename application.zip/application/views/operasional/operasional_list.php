<div class="row page-titles">
    <div class="col-md-5 col-12 align-self-center">
        <h3 class="text-themecolor mb-0">Info Operasional</h3>
    </div>
</div>

<div style="min-height: calc(100vh - 180px);">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row" style="margin-bottom: 10px">
                    <div class="col-md-4">
                        <?php echo anchor(site_url("operasional/create"), "Tambah Data", "class='btn btn-info'"); ?>
                    </div>
                    <div class="col-md-4 text-center">
                        <div style="margin-top: 8px" id="message">
                            <?php echo $this->session->userdata("message") <> "" ? $this->session->userdata("message") : ""; ?>
                        </div>
                    </div>
                    <div class="col-md-1 text-right">
                    </div>
                    <div class="col-md-3 text-right">
                        <form action="<?php echo site_url("operasional/index"); ?>" class="form-inline" method="get">
                            <div class="input-group">
                                <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                                <span class="input-group-btn">
                                    <?php
                        if ($q <> "") {
                            ?>
                                    <a href="<?php echo site_url("operasional"); ?>" class="btn btn-default">Reset</a>
                                    <?php
                        }
                    ?>
                                    <button class="btn btn-info" type="submit">Search</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>



                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="bg-info text-white">
                            <tr>
                                <th>Nama</th>
                                <th>Keterangan</th>
                                <th>Operasional Status</th>
                                <th>Operasi</th>
                            </tr>
                        </thead>
                        <tbody class="border border-info"><?php
            foreach ($operasional_data as $operasional) {
                ?>
                            <tr>
                                <td><?php echo $this->Reza_model->show_ref($this->db->database, "operasional", "nama") ? $this->Reza_model->get_ref_val($this->db->database, 'operasional', 'nama', $operasional->nama)->nama : $operasional->nama; ?>
                                </td>
                                <td><?php echo $this->Reza_model->show_ref($this->db->database, "operasional", "keterangan") ? $this->Reza_model->get_ref_val($this->db->database, 'operasional', 'keterangan', $operasional->keterangan)->nama : $operasional->keterangan; ?>
                                </td>
                                <td><?php echo $this->Reza_model->show_ref($this->db->database, "operasional", "operasional_status") ? $this->Reza_model->get_ref_val($this->db->database, 'operasional', 'operasional_status', $operasional->operasional_status)->nama : $operasional->operasional_status; ?>
                                </td>
                                <td style="text-align:center" width="200px">
                                    <?php
                echo anchor(site_url('operasional/read/'.$operasional->id), 'Lihat', 'class="btn btn-xs waves-effect waves-light btn-outline-dark"');
                echo ' | ';
                echo anchor(site_url('operasional/update/'.$operasional->id), 'Ubah', 'class="btn btn-xs waves-effect waves-light btn-outline-warning"');
                echo ' | ';
                echo anchor(site_url('operasional/delete/'.$operasional->id), 'Hapus', 'class="btn btn-xs waves-effect waves-light btn-outline-danger" onclick="javasciprt: return confirm(\'Apa kamu yakin? Data yg terhapus tidak dapat dikembalikan!!\')"'); ?>
                                </td>
                            </tr><?php
            } ?>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <span class="btn btn-info">Jumlah Data <span class="badge badge-light"><?php echo $total_rows ?></span></span>

                    </div>
                    <div class="col-md-6 text-right">
                        <?php echo $pagination ?>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <ul class="feeds">
        <li class="feed-item d-flex align-items-center">
            <div class="card border-dark">
                <div class="card-header bg-dark">
                    <h4 class="mb-0 text-white">Card Title</h4>
                </div>
                <div class="card-body">
                    <h3 class="card-title">Special title treatment</h3>
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <button class="btn btn-primary ml-1" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                        Button with data-target
                    </button>
                </div>
            </div>
        </li>
        <li class="feed-item d-flex align-items-center">

            <ul class="feeds collapse" id="collapseExample">
                <li class="feed-item d-flex align-items-center">
                    <div class="col-12 single-note-item all-category note-social">
                        <div class="card card-body ">
                            <span class="side-stick"></span>
                            <h5 class="note-title text-truncate w-75 mb-0" data-noteheading="Nightout with friends">Nightout with friends <i class="point fas fa-circle ml-1 font-10"></i></h5>
                            <p class="note-date font-12 text-muted">01 August 1999</p>
                            <div class="note-content">
                                <p class="note-inner-content text-muted" data-notecontent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.</p>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="mr-1"><i class="far fa-star favourite-note"></i></span>
                                <span class="mr-1"><i class="far fa-trash-alt remove-note"></i></span>
                                <div class="ml-auto">
                                    <div class="category-selector btn-group">
                                        <a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">
                                            <div class="category">
                                                <div class="category-business"></div>
                                                <div class="category-social"></div>
                                                <div class="category-important"></div>
                                                <span class="more-options text-dark"><i class="icon-options-vertical"></i></span>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right category-menu">
                                            <a class="note-business badge-group-item badge-business dropdown-item position-relative category-business text-success" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Business</a>
                                            <a class="note-social badge-group-item badge-social dropdown-item position-relative category-social text-info" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i> Social</a>
                                            <a class="note-important badge-group-item badge-important dropdown-item position-relative category-important text-danger" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i> Important</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="feed-item d-flex align-items-center">
                    <div class="card border-dark">
                        <div class="card-header bg-dark">
                            <h4 class="mb-0 text-white">Card Title</h4>
                        </div>
                        <div class="card-body">
                            <h3 class="card-title">Special title treatment</h3>
                            <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                            <a href="javascript:void(0)" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </li>
            </ul>
        </li>
    </ul>



</div>