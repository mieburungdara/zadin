<?php
 function tgl_ind($date)
 {
 
    // array hari dan bulan
     $Hari = array("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu");
     $Bulan = array("Januari","Februari","Maret","April","Mei","Juni",
                   "Juli","Agustus","September","Oktober","November","Desember");
    
     // pemisahan tahun, bulan, hari, dan waktu
     $tahun = substr($date, 0, 4);
     $bulan = substr($date, 5, 2);
     $tgl = substr($date, 8, 2);
     $waktu = substr($date, 11, 5);
     $hari = date("w", strtotime($date));
     $result = $waktu." ".$Hari[$hari].", ".$tgl." ".$Bulan[(int)$bulan-1]." ".$tahun;
     return $result;
 }
?>
<script src="<?=base_url(); ?>assets/libs/typeahead.js/dist/typeahead.jquery.min.js"></script>
<script src="<?=base_url(); ?>assets/libs/typeahead.js/dist/bloodhound.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
<script src="<?=base_url(); ?>assets/libs/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
<style>
    .vertical-nav-menu {
        margin: 0;
        padding: 0;
        position: relative;
        list-style: none
    }

    .vertical-nav-menu::after {
        content: " ";
        pointer-events: none;
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        top: 0
    }

    .vertical-nav-menu .mm-collapse:not(.mm-show) {
        display: none
    }

    .vertical-nav-menu .mm-collapsing {
        position: relative;
        height: 0;
        overflow: hidden;
        transition-timing-function: ease;
        transition-duration: .25s;
        transition-property: height, visibility
    }

    .vertical-nav-menu ul {
        margin: 0;
        padding: 0;
        position: relative;
        list-style: none
    }

    .vertical-nav-menu:before {
        opacity: 0;
        transition: opacity 300ms
    }

    .vertical-nav-menu li a {
        display: block;
        line-height: 2.4rem;
        height: 2.4rem;
        padding: 0 1.5rem 0 45px;
        position: relative;
        border-radius: .25rem;
        color: #343a40;
        white-space: nowrap;
        transition: all .2s;
        margin: .1rem 0
    }

    .vertical-nav-menu li a:hover {
        background: #e0f3ff;
        text-decoration: none
    }

    .vertical-nav-menu li a:hover i.metismenu-icon {
        opacity: .6
    }

    .vertical-nav-menu li a:hover i.metismenu-state-icon {
        opacity: 1
    }

    .vertical-nav-menu li.mm-active>a {
        font-weight: 700
    }

    .vertical-nav-menu li.mm-active>a i.metismenu-state-icon {
        transform: rotate(-180deg)
    }

    .vertical-nav-menu li a.mm-active {
        color: #3f6ad8;
        background: #e0f3ff;
        font-weight: 700
    }

    .vertical-nav-menu i.metismenu-state-icon,
    .vertical-nav-menu i.metismenu-icon {
        text-align: center;
        width: 34px;
        height: 34px;
        line-height: 34px;
        position: absolute;
        left: 5px;
        top: 50%;
        margin-top: -17px;
        font-size: 1.5rem;
        opacity: .3;
        transition: color 300ms
    }

    .vertical-nav-menu i.metismenu-state-icon {
        transition: transform 300ms;
        left: auto;
        right: 0
    }

    .vertical-nav-menu ul {
        transition: padding 300ms;
        padding: .5em 0 0 2rem
    }

    .vertical-nav-menu ul:before {
        content: '';
        height: 100%;
        opacity: 1;
        width: 3px;
        background: #e0f3ff;
        position: absolute;
        left: 20px;
        top: 0;
        border-radius: 15px
    }

    .vertical-nav-menu ul>li>a {
        color: #6c757d;
        height: 2rem;
        line-height: 2rem;
        padding: 0 1.5rem
    }

    .vertical-nav-menu ul>li>a:hover {
        color: #3f6ad8
    }

    .vertical-nav-menu ul>li>a .metismenu-icon {
        display: none
    }

    .vertical-nav-menu ul>li>a.mm-active {
        color: #3f6ad8;
        background: #e0f3ff;
        font-weight: 700
    }


    .task-list {
        list-style: none;
        position: relative;
        margin: 0;
        padding: 30px 0 0;
    }

    .task-list:after {
        content: "";
        position: absolute;
        background: #ecedef;
        height: 100%;
        width: 2px;
        top: 0;
        left: 30px;
        z-index: 1;
    }

    .task-list li {
        margin-bottom: 30px;
        padding-left: 55px;
        position: relative;
    }

    .task-list li:last-child {
        margin-bottom: 0;
    }

    .task-list li .task-icon {
        position: absolute;
        left: -20px;
        /* left: 22px; */
        /* top: 13px; */
        /* border-radius: 50%;
        padding: 2px;
        width: 17px;
        height: 17px; */
        z-index: 2;
        -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.2);
        box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.2);
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/metismenu"></script>


<div class="email-app todo-box-container">
    <div class="left-part list-of-tasks">
        <a class="ti-close btn btn-success show-left-part d-block d-md-none ti-menu" href="javascript:void(0)"></a>
        <div class="scrollable ps-container" style="height:100%;">
            <div class="p-3">
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#signup-modal">Buat Operasional Baru</button>
            </div>
            <div class="p-3">
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#operasional-baru-modal">Buat Invoice Baru</button>
            </div>
            <div class="divider"></div>
            <ul class="list-group pt-3">
                <li>
                    <small class="p-3 ">Permohonan &amp; Invoice</small>
                </li>
                <li class="list-group-item p-0 border-0">
                    <a href="javascript:void(0)" class="list-group-item-action p-3 d-block "><i class="mdi mdi-format-list-bulleted"></i> Permohonan <span class="todo-badge badge badge-info float-right">5</span></a>
                </li>
                <li class="list-group-item p-0 border-0">
                    <a href="javascript:void(0)" class="list-group-item-action p-3 d-block"> <i class="mdi mdi-book"></i> Important <span class="todo-badge badge badge-warning float-right">2</span></a>
                </li>
            </ul>
            <div class="ps-scrollbar-x-rail" style="left: 0px; bottom: 0px;">
                <div class="ps-scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div>
            </div>
            <div class="ps-scrollbar-y-rail" style="top: 0px; right: 3px;">
                <div class="ps-scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div>
            </div>
        </div>
    </div>

    <div class="right-part bg-white overflow-auto">
        <div class="container-fluid">


            <div class="p-3 border-bottom">
                <div class="row">
                    <div class="col-1">
                        <a class="waves-effect waves-light btn btn-info " href="javascript: void(0)" id="add-task">Kembali</a>
                    </div>
                    <div class="col-10">
                        <h3><?= $nama ?>
                        </h3>
                        <h6><?= $keterangan ?>
                        </h6>
                        <small class="font-12 text-muted"><i class="icon-calender mr-1"></i><?= tgl_ind(date_format(date_create($created_at), "Y-m-d H:i:s")) ?></small>
                    </div>
                </div>
            </div>

            <div class="row justify-content-end pt-3">
                <div class="border-start-primary col-auto">
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="float-right">
                                <i class="ti-write text-primary h4 ml-3"></i>
                            </div>
                            <h5 class="font-size-20 mt-0 pt-1">24</h5>
                            <p class="text-muted mb-0">Total Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="float-right">
                                <i class="far fa-th text-primary h4 ml-3"></i>
                            </div>
                            <h5 class="font-size-20 mt-0 pt-1">18</h5>
                            <p class="text-muted mb-0">Completed Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="float-right">
                                <i class="fa fa-file text-primary h4 ml-3"></i>
                            </div>
                            <h5 class="font-size-20 mt-0 pt-1">06</h5>
                            <p class="text-muted mb-0">Pending Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="card">
                        <div class="card-body">
                            <form>
                                <div class="form-group mb-0">
                                    <label>Search</label>
                                    <div class="input-group mb-0">
                                        <input type="text" class="form-control" placeholder="Search..." aria-describedby="project-search-addon" />
                                        <div class="input-group-append">
                                            <button class="btn btn-danger" type="button" id="project-search-addon"><i class="fa fa-search search-icon font-12"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div id="note-full-container" class="note-has-grid row">
                    <div class="col-auto single-note-item all-category note-social">
                        <div class="card card-body ">
                            <span class="side-stick"></span>
                            <span class="mr-1"><i class="fa fa-warning text-danger faa-flash faa-fast animated"></i> No RKBM </span>
                            <h5 class="note-title text-truncate w-75 mb-0" data-noteheading="Meeting with Mr.Jojo">Meeting with Mr.Jojo <i class="point fas fa-circle ml-1 font-10"></i></h5>
                            <p class="note-date font-12 text-muted">19 October 2020</p>
                            <div class="note-content">
                                <p class="note-inner-content text-muted" data-notecontent="Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.">Blandit tempus porttitor aasfs. Integer posuere erat a ante venenatis.</p>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="mr-1"><i class="far fa-trash-alt remove-note"></i></span>
                                <div class="ml-auto">
                                    <div class="category-selector btn-group">
                                        <a class="nav-link dropdown-toggle category-dropdown label-group p-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                            <div class="category">
                                                <div class="category-business"></div>
                                                <div class="category-social"></div>
                                                <div class="category-important"></div>
                                                <span class="more-options text-dark"><i class="icon-options-vertical"></i></span>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right category-menu" style="">
                                            <a class="note-business badge-group-item badge-business dropdown-item position-relative category-business text-success" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i>Business</a>
                                            <a class="note-social badge-group-item badge-social dropdown-item position-relative category-social text-info" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i> Social</a>
                                            <a class="note-important badge-group-item badge-important dropdown-item position-relative category-important text-danger" href="javascript:void(0);"><i class="mdi mdi-checkbox-blank-circle-outline mr-1"></i> Important</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <ul class="vertical-nav-menu">
                <li>
                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                                <tr>
                                    <td>
                                        <span class="btn btn-xs btn-info" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                            <i class="fa fa-arrow-down" aria-expanded="false"></i> Revisi
                                        </span>
                                    </td>
                                    <td>
                                        <b>No.RKBM</b> :
                                        <code>005</code>
                                    </td>
                                    <td><span class="badge badge-info">MUAT</span></td>
                                    <td>Mulai:<br>Selesai:</td>
                                    <td>Laporan Baru</td>
                                    <td>PBM:PT.ZADIN MITRA ABADI<br>Asal Muatan: Tambang ABC</td>
                                    <td>
                                        Kapal: abc<br>
                                        Tempat Muat : abc<br>
                                        Tempat Bongkar : abc<br>
                                        Barang : Batu Bara<br>
                                        Muatan Perkiraan : 7500.000<br>
                                        Muatan Asli : 7500.000<br>
                                        Muatan Bongkar : 7500.000<br>
                                    </td>
                                    <td>
                                        <div class="dropdown-action">
                                            <div class="dropdown todo-action-dropdown">
                                                <button class="btn btn-link text-dark p-1 dropdown-toggle text-decoration-none todo-action-dropdown" type="button" id="more-action-1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                    <i class="icon-options-vertical"></i>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="more-action-1" style="position: absolute; transform: translate3d(-134px, -136px, 0px); top: 0px; left: 0px; will-change: transform;" x-placement="top-end">
                                                    <a class="edit dropdown-item" href="javascript:void(0);"><i class="fas fa-edit text-info mr-1"></i> Edit</a>
                                                    <a class="important dropdown-item" href="javascript:void(0);"><i class="fas fa-star text-warning mr-1"></i> Important</a>
                                                    <a class="remove dropdown-item" href="javascript:void(0);"><i class="far fa-trash-alt text-danger mr-1"></i>Remove</a>
                                                    <a class="dropdown-item permanent-delete" href="javascript:void(0);"><i class="fas fa-trash text-danger mr-1"></i>Permanent Delete</a>
                                                    <a class="dropdown-item revive" href="javascript:void(0);"><i class="fas fa-undo-alt text-success mr-1"></i>Revive Task</a>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <ul class="collapse" id="collapseExample">
                        <li>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <button class="btn btn-primary ml-1" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                                    Button with data-target
                                                </button>
                                            </td>
                                            <td>Nigam</td>
                                            <td>Eichmann</td>
                                            <td>@Sonu</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>



    <div id="signup-modal" class="modal fade" tabindex="-1" data-backdrop="static" role="dialog" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <div class="modal-body">
                    <div class="text-center mt-2 mb-4">
                        <h4>Buat Permohona</h4>
                    </div>

                    <form action="rkbm/create_action" method="post">
                        <div class="card-body">
                            <div class="row mt-3">

                                <div class="col-sm-12 col-md-6">
                                    <label for="tanggal_muat">Rencana Muat / Mulai</label>
                                    <div class="input-group form-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="icon-calender"></i></span>
                                        </div>
                                        <input type="text" id="tanggal_muat" class=" form-control mydatepicker" data-date-format="yyyy-mm-dd" placeholder="yyyy-mm-dd">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <label for="tanggal_selesai">Tanggal Selesai</label>
                                    <div class="input-group form-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="icon-calender"></i></span>
                                        </div>
                                        <input type="text" id="tanggal_selesai" class="form-control mydatepicker" data-date-format="yyyy-mm-dd" placeholder="yyyy-mm-dd">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="agen_kapal">Agen Kapal</label>
                                        <select class="custom-select mr-sm-2 wide" name="agen_kapal" id="agen_kapal" placeholder="Agen Kapal">
                                            <option disabled <?php
    echo 'selected="selected"';
?>>Pilih...
                                            </option>
                                            <?php
$agen_kapals = $this->Agen_kapal_model->get_all();
foreach ($agen_kapals as $palu) {
    echo "<option value='" . $palu->id . "' >" . $palu->nama . "</option>";
}
?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="nama_kapal">Nama Kapal</label>
                                        <code id="ket"></code>
                                        <select class="custom-select mr-sm-2" disabled name="nama_kapal" id="nama_kapal" placeholder="Nama Kapal">
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="jenis_terminal">Jenis Terminal</label>
                                        <select class="custom-select mr-sm-2 wide" name="jenis_terminal" id="jenis_terminal" placeholder="Jenis Terminal">
                                            <option disabled <?php
    echo 'selected="selected"';

?>>Pilih..
                                            </option>
                                            <?php
$agen_kapals = $this->Jenis_terminal_model->get_all();
foreach ($agen_kapals as $palu) {
    echo "<option value='" . $palu->id . "'>" . strtoupper($palu->nama) . "</option>";
}
?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="username">Nama Terminal</label>
                                        <select class="custom-select mr-sm-2" disabled name="nama_terminal" id="nama_terminal" placeholder="Nama Terminal">
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="tujuan">Tempat Bongkar/Tujuan</label>
                                        <input class="form-control" type="text" id="tujuan" name="tujuan" placeholder="Pilih..">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="barang">Jenis Barang</label>
                                        <select class="custom-select mr-sm-2" name="barang" id="barang" placeholder="Nama Terminal">
                                            <option disabled <?php
    echo 'selected="selected"';
?>>Pilih..
                                            </option>
                                            <?php
$agen_kapals = $this->Barang_model->jenis_barang();
foreach ($agen_kapals as $palu) {
    echo "<option value='" . $palu->id . "'>" . strtoupper($palu->nama) . "</option>";
}
?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4">
                                    <div class="form-group">
                                        <label for="username" data-toggle="tooltip" data-placement="top" title="" data-original-title="Muatan yang direncanakan">Jumlah Muat</label>
                                        <input class="form-control" type="text" id="jumlah" name="jumlah" placeholder="Contoh: 7500">
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4">
                                    <div class="form-group">
                                        <label for="jumlah_real" data-toggle="tooltip" data-placement="top" title="" data-original-title="Muatan yang sebenarnya">Jumlah Sebenarnya</label>
                                        <input class="form-control" type="text" id="jumlah_real" name="jumlah_real" placeholder="Contoh: 7500">
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4">
                                    <div class="form-group">
                                        <label for="bongkar" data-toggle="tooltip" data-placement="top" title="" data-original-title="RKBM bongkar">Jumlah Bongkaran</label>
                                        <input class="form-control" type="text" id="bongkar" name="bongkar" placeholder="Contoh: 7500">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="asal_brg">Asal Barang</label>
                                        <select class="custom-select mr-sm-2 wide" name="asal_brg" id="asal_brg" placeholder="Asal Barang">
                                            <option disabled <?php
    echo 'selected="selected"';

?>>Choose...
                                            </option>
                                            <?php
$agen_kapals = $this->Asal_pemilik_model->get_asal();
foreach ($agen_kapals as $palu) {
    echo "<option value='" . $palu->id . "'>" . $palu->nama . "</option>";
}
?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="perusahaan">Perusahaan PBM</label>
                                        <select class="custom-select mr-sm-2 wide" name="perusahaan" id="perusahaan" placeholder="Agen Kapal">
                                            <option disabled <?php
    echo 'selected="selected"';

?>>Choose...
                                            </option>
                                            <?php
$agen_kapals = $this->Perusahaan_model->get_all();
foreach ($agen_kapals as $palu) {
    echo "<option value='" . $palu->id . "'>" . $palu->nama . "</option>";
}
?>
                                        </select>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="action-form">
                                        <div class="form-group mb-0 text-right"><input type="hidden" name="id" value="<?php echo $id; ?>" /><button type="submit" class="btn btn-info waves-effect waves-light">Save</button><a href="<?=site_url('rkbm'); ?>" class="btn btn-dark waves-effect waves-light">Cancel</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>



</div>

<script src="<?=base_url(); ?>assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="<?=base_url(); ?>assets/libs/bootstrap-datepicker/dist/locales/bootstrap-datepicker.id.min.js"></script>
<script>
    // Date Picker
    jQuery('.mydatepicker').datepicker({
        maxViewMode: 2,
        todayBtn: "linked",
        clearBtn: true,
        language: "id",
        autoclose: true,
        todayHighlight: true
    });
</script>
<script>
    $(document).ready(function() {

        $('#nama_kapal').change(function() {
            var ukuran = $(this).children('option:selected').attr('data-ukuran');
            var bendera = $(this).children('option:selected').attr('data-bendera');
            // alert($(this).children('option:selected').data('id'));
            $('#ket').html('' + bendera + ' ~ ' + ukuran + '');
        });

        $("#jumlah").inputmask("9.999.999");
        $("#jumlah_real").inputmask("9.999.999");
        $("#bongkar").inputmask("9.999.999");

        $("#agen_kapal").change(function() {
            field = this.value;
            $('#nama_kapal').prop("disabled", false); // Element(s) are now enabled.
            $.ajax({
                type: "POST",
                data: {
                    "id": field
                },
                url: "<?=base_url(); ?>kapal/read_json",
                success: function(data) {
                    $("#nama_kapal").html(data);
                }
            });
        });

        $("#jenis_terminal").change(function() {
            field = this.value;
            $('#nama_terminal').prop("disabled", false); // Element(s) are now enabled.
            $.ajax({
                type: "POST",
                data: {
                    "id": field
                },
                url: "<?=base_url(); ?>terminal/read_json",
                success: function(data) {
                    $("#nama_terminal").html(data);
                }
            });
        });

        var substringMatcher = function(strs) {
            return function findMatches(q, cb) {
                var matches, substringRegex;
                matches = [];
                substrRegex = new RegExp(q, 'i');
                $.each(strs, function(i, str) {
                    if (substrRegex.test(str)) {
                        matches.push(str);
                    }
                });
                cb(matches);
            };
        };

        <?php

$this->db->select('tujuan');
$hasil = $this->db->get('rkbm')->result();
$ds    = array();
foreach ($hasil as $key => $value) {
    if (!in_array($value, $ds)) {
        $ds[$key] = $value;
    }
}
foreach ($ds as $item) {
    $dull[] = $item->tujuan;
}
$red = json_encode($dull);
?>
        var xer = <?php echo $red; ?> ;
        $('#tujuan').typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
            // name: 'states',
            source: substringMatcher(xer)
        });


        <?php
// $this->db->select('jumlah');
// $sdnyulbd  = $this->db->get('rkbm')->result();
// $wftrtynbt = array();
// foreach ($sdnyulbd as $key => $value) {
//     if (!in_array($value, $wftrtynbt)) {
//         $wftrtynbt[$key] = $value;
//     }
// }
// foreach ($wftrtynbt as $ulikyjthtr) {
//     $jehbt[] = str_replace('.000', '', $ulikyjthtr->jumlah);
// }
// $ergvr = json_encode($jehbt);?>
        // var dtp = <?php //echo //$ergvr;?>;
        // $('#jumlah').typeahead({
        //     hint: true,
        //     highlight: true,
        //     minLength: 1
        // }, {
        //     // name: 'states',
        //     source: substringMatcher(dtp)
        // });

    });



    // var brg = ["BATU BARA"];
    // var ada = new Bloodhound({
    //     datumTokenizer: Bloodhound.tokenizers.whitespace,
    //     queryTokenizer: Bloodhound.tokenizers.whitespace,
    //     identify: function(obj) {
    //         return obj;
    //     },
    //     local: brg
    // });

    // function xs(q, sync) {
    //     if (q === '') {
    //         sync(ada.get('BATU BARA'));
    //     } else {
    //         ada.search(q, sync);
    //     }
    // }

    // $('#barang').typeahead({
    //     minLength: 0,
    //     hint: true,
    //     highlight: true
    // }, {
    //     source: xs
    // });
</script>