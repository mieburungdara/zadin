<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Perusahaan_pengiriman Read</h2>
        <table class="table">
	    <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
	    <tr><td>Alamat</td><td><?php echo $alamat; ?></td></tr>
	    <tr><td>Sk</td><td><?php echo $sk; ?></td></tr>
	    <tr><td>Npwp</td><td><?php echo $npwp; ?></td></tr>
	    <tr><td>Pph</td><td><?php echo $pph; ?></td></tr>
	    <tr><td>Total Pph</td><td><?php echo $total_pph; ?></td></tr>
	    <tr><td>Unix</td><td><?php echo $unix; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('perusahaan_pengiriman') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>