<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    Belum di isi
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-2 col-md-4">
            <div class="card border-bottom border-info">
                <div class="card-body">
                    <div class="d-flex no-block align-items-center">
                        <div>
                            <h2>120</h2>
                            <h6 class="text-info">Total Permohonan</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4">
            <div class="card border-bottom border-info">
                <div class="card-body">
                    <div class="d-flex no-block align-items-center">
                        <div>
                            <h2>120</h2>
                            <h6 class="text-info">Total Proses</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4">
            <div class="card border-bottom border-info">
                <div class="card-body">
                    <div class="d-flex no-block align-items-center">
                        <div>
                            <h2>120</h2>
                            <h6 class="text-info">Total Selesai</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4">
            <div class="card border-bottom border-info">
                <div class="card-body">
                    <div class="d-flex no-block align-items-center">
                        <div>
                            <h2>120</h2>
                            <h6 class="text-info">Total Batal</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4">
            <div class="card border-bottom border-info">
                <div class="card-body">
                    <div class="d-flex no-block align-items-center">
                        <div>
                            <h2>120</h2>
                            <h6 class="text-info">Total Revisi</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4">
            <div class="card border-bottom border-info">
                <div class="card-body">
                    <div class="d-flex no-block align-items-center">
                        <div>
                            <h2>120</h2>
                            <h6 class="text-info">Total Perpanjang</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
</div>