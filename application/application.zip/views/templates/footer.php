<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Developed </b>with <span class="text-danger"> ❤ </span> by Rahmat Subandi
  </div>
  <strong> &copy; 2020 - <?php echo date('Y'); ?> - Parking Management System
</footer>

<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
<!-- ./wrapper -->

</body>

</html>